package com.hjjangela.mas;

/**
 * @author Administrator
 * @des ${TODO}
 * @verson $Rev$
 * @updateAuthor $Author$
 * @updateDes ${TODO}
 */
public class IPAddress {
    public static final String ipaddress = "13.250.200.177";
}